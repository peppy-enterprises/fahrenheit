﻿namespace FFXCutsceneRemover;

interface IGameState
{
    bool CheckState();
}