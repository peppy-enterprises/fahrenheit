﻿namespace Fahrenheit.CoreLib.FFX2;

public static unsafe class Globals {
	public static nint game_base = FhPInvoke.GetModuleHandle("FFX-2.exe");
}
