﻿namespace Fahrenheit.CoreLib.FFX;

public static unsafe class Globals {
    public static nint game_base = FhPInvoke.GetModuleHandle("FFX.exe");

    public static ushort* pad_input = (ushort*)(game_base + 0xF27080);

    public static uint security_cookie => *(uint*)(game_base + 0x8613D8);

    public static class Map {
        public static int* tri_count = (int*)(game_base + 0xF01A48);
        public static VpaTri* tris = (VpaTri*)(game_base + 0xF01A44);
        public static VpaVertex* vertices = (VpaVertex*)(game_base + 0xF01A4C);
        public static float* scale = (float*)(game_base + 0xF01A50);
        public static VpaNavMesh* navmesh = (VpaNavMesh*)(game_base + 0xF01A54);
    }

    public static BtlStruct* btl = (BtlStruct*)(game_base + 0xD2A8D0);
    public static BtlDataStruct* btl_data = (BtlDataStruct*)(game_base + 0x1F10EA0);
    public static SaveDataStruct* save_data = (SaveDataStruct*)(game_base + 0xD2CA90);
    public static ParamDataStruct* param_data = (ParamDataStruct*)(game_base + 0x1F11240);

    public static int* atel_request_count = (int*)(game_base + 0xD34564);
    public static AtelRequest* atel_request_list = (AtelRequest*)(game_base + 0xD35D68);

    public static AtelWorkerController* atel_ctrl_workers = (AtelWorkerController*)(game_base + 0xF25B60);

    public static AtelBasicWorker* cur_atel_worker = (AtelBasicWorker*)(game_base + 0xF270A4);
    public static AtelWorkerController* cur_ctrl_atel_worker = (AtelWorkerController*)(game_base + 0xF26AE8);

    public static BtlComWindow* btl_com_windows = (BtlComWindow*)(game_base + 0xF3C910);
    public static BtlStatusWindow* btl_status_windows = (BtlStatusWindow*)(game_base + 0xF3F798);

    public static float* tidus_limit_times = (float*)(game_base + 0x886BF0);
    public static float* auron_limit_times = (float*)(game_base + 0x886B60);

    public static byte* hit_chance_table = (byte*)(game_base + 0x8421E0);
}

