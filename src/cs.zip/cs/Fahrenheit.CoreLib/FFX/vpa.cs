﻿namespace Fahrenheit.CoreLib.FFX;

public enum VpaTriCollisionGroup {
    Pass = 0,
    BlockAll = 1,
    BlockNPC = 2,
    BlockPlayer = 14,
}

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 0x10)]
public unsafe struct VpaTri {
    [FieldOffset(0x0)] public fixed short vertex_indices[3];
    public readonly VpaVertex* vertex(int idx) => Globals.Map.vertices + vertex_indices[idx];
    public readonly VpaVertex* vertA => Globals.Map.vertices + vertex_indices[0];
    public readonly VpaVertex* vertB => Globals.Map.vertices + vertex_indices[1];
    public readonly VpaVertex* vertC => Globals.Map.vertices + vertex_indices[2];

    [FieldOffset(0x6)] public fixed short neighbour_indices[3];
    public readonly VpaTri* neighbour(int idx) => Globals.Map.tris + neighbour_indices[idx];
    public readonly VpaTri* neighbourA => Globals.Map.tris + neighbour_indices[0];
    public readonly VpaTri* neighbourB => Globals.Map.tris + neighbour_indices[1];
    public readonly VpaTri* neighbourC => Globals.Map.tris + neighbour_indices[2];

    [FieldOffset(0xC)] private int data;
    public VpaTriCollisionGroup collision_group { get => (VpaTriCollisionGroup)data.get_bits(0, 7); set => data.set_bits(0, 7, (int)value); }
    public int battle_zone { get => data.get_bits(7, 2); set => data.set_bits(7, 2, value); }
    public int unk1 { get => data.get_bits(9, 2); set => data.set_bits(9, 2, value); }
    public int location { get => data.get_bits(11, 2); set => data.set_bits(11, 2, value); }
    public int unk2 { get => data.get_bits(13, 2); set => data.set_bits(13, 2, value); }
    public int sound_type { get => data.get_bits(15, 2); set => data.set_bits(15, 2, value); }
    public int upper { get => data.get_bits(17, 15); set => data.set_bits(17, 15, value); }

}

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 0x8)]
public unsafe struct VpaVertex {
    [FieldOffset(0x0)] public short x;
    [FieldOffset(0x2)] public short y;
    [FieldOffset(0x4)] public short z;
    [FieldOffset(0x6)] private short unused;
}

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 0x20)]
public unsafe struct VpaNavMesh {
    [FieldOffset(0xA)] public ushort vertex_count;
    [FieldOffset(0xC)] public float scale;
    [FieldOffset(0x18)] public uint vertices_offset;
    [FieldOffset(0x1C)] public uint tri_info_offset;
}
