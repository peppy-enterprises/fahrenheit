﻿global using T_FhDialogueOptionCount = System.Byte;
global using T_FhDialoguePos         = System.UInt16;
